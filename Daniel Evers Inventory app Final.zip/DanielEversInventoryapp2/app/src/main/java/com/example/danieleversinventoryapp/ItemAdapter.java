package com.example.danieleversinventoryapp;

import android.app.AlertDialog;
import android.content.Context;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private ArrayList<Item> items;
    private DBHelper db;
    private Context context;

    public ItemAdapter(Context context, ArrayList<Item> items, DBHelper db) {
        this.context = context;
        this.items = items;
        this.db = db;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameView, qtyView;
        Button deleteBtn, updateBtn;

        public ViewHolder(View view) {
            super(view);
            nameView = view.findViewById(R.id.textName);
            qtyView = view.findViewById(R.id.textQuantity);
            deleteBtn = view.findViewById(R.id.buttonDelete);
            updateBtn = view.findViewById(R.id.buttonUpdate);
        }
    }

    @Override
    public ItemAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Item item = items.get(position);
        holder.nameView.setText(item.name);
        holder.qtyView.setText("Qty: " + item.quantity);

        // Delete
        holder.deleteBtn.setOnClickListener(v -> {
            db.deleteItem(item.id);
            items.remove(position);
            notifyItemRemoved(position);
            Toast.makeText(context, "Item deleted", Toast.LENGTH_SHORT).show();
        });

        // Update
        holder.updateBtn.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            View dialogView = LayoutInflater.from(context).inflate(R.layout.update_item, null);
            EditText nameInput = dialogView.findViewById(R.id.editUpdateName);
            EditText qtyInput = dialogView.findViewById(R.id.editUpdateQty);
            nameInput.setText(item.name);
            qtyInput.setText(String.valueOf(item.quantity));

            builder.setView(dialogView)
                    .setTitle("Update Item")
                    .setPositiveButton("Update", (dialog, which) -> {
                        String newName = nameInput.getText().toString();
                        int newQty = Integer.parseInt(qtyInput.getText().toString());
                        db.updateItem(item.id, newName, newQty);
                        item.name = newName;
                        item.quantity = newQty;
                        notifyItemChanged(position);
                        Toast.makeText(context, "Item updated", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
